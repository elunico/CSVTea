# CSV Tea

This is a Python package created to parse CSV files that contain new lines in its cells. 
More broadly, the goal is to be able to parse CSV files with more pluggability, extensibility, and flexibility, than is normally allowed by the CSV format. 

Contributions & Suggestions welcome.
